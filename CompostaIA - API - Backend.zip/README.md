# Instalar venv
* Instalar uv si no lo tienes
> Windows:```irm https://astral.sh/uv/install.ps1 | iex```

1. Crear entorno, instalar dependencias: ```uv sync```
2. Activar entorno: ```.venv\Scripts\Activate.ps1```


# Ejecutar el proyecto
Ejecuta: ```.\dev.ps1```